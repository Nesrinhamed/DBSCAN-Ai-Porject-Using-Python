import collections


class Node:
    id = None  # Unique value for each node.
    up = None  # Represents value of neighbors (up, down, left, right).
    down = None
    left = None
    right = None
    previousNode = None  # Represents value of neighbors.
    edgeCost = None  # Represents the cost on the edge from any parent to this node.
    gOfN = None  # Represents the total edge cost
    hOfN = None  # Represents the heuristic value
    heuristicFn = None  # Represents the value of heuristic function

    ################################################################################333333333
    # Visted Node Function To get The next Node
    def Visted_Node(self, V, C):
        if C.left <= 0 and V.__contains__(C.left) == True:
            return C.left

        elif C.right <= 0 and V.__contains__(C.right) == True:
            return C.right

        elif C.up <= 0 and V.__contains__(C.up) == True:
            return C.up

        elif C.down <= 0 and V.__contains__(C.down) == True:
            return C.down

        else:
            return -1

    ########################################################################################################
    def __init__(self, value):
        self.value = value
    def Moves(Node):
        MyList=[]






class SearchAlgorithms:
    ''' * DON'T change Class, Function or Parameters Names and Order
        * You can add ANY extra functions,
          classes you need as long as the main
          structure is left as is '''
    ''' maze_string = ''
    node_2d_list = []
    row_count = 0
    col_count = 0
    start_row_index = 0
    start_col_index = 0
    start_id = 0
    end_row_index = 0
    end_col_index = 0
    end_id = 0'''
    N = {}  # Nodes Set
    # N= []
    # V =[]
    heuristic = []  # Heoristic matrix
    S = 0  # Start node
    E = 0  # End node
    New_maze = []
    id = 0  # ID For each Node
    Maze = []
    R_Matrix = []
    path = []  # Represents the correct path from start node to the goal node.
    fullPath = []  # Represents all visited nodes from the start node to the goal node.
    totalCost = -1  # Represents the total cost in case using UCS, AStar
    # E_maze = []
    closelist = []
    O_Maze = []

    ###########################################################################################################
    #################################### Creating Maze ###############################################3
    def __init__(self, mazeStr, heristicValue=None):
        ''' mazeStr contains the full board
         The board is read row wise,
        the nodes are numbered 0-based starting
        the leftmost node'''
        ''' for i in range(self.row_count):
            for j in range(self.col_count):
                self.node_2d_list[i][j].visited_color = 'White'
                self.node_2d_list[i][j].previousNode = None

        BFS_queue = collections.deque([self.node_2d_list[self.start_row_index][self.start_col_index]])

        while BFS_queue:

            currentNode = BFS_queue.pop()
            self.fullPath.append(currentNode.id)

            if currentNode.id == self.end_id:
                break



            currentNode.right.col_index].previousNode = currentNode

            self.node_2d_list[currentNode.row_index][currentNode.col_index].visited_color = 'Black'

        x = self.node_2d_list[self.end_row_index][self.end_col_index]
        while x.value != 'S':
            self.path.append(x.id)
            x = x.previousNode

        self.path.append(self.start_id)
        self.path.reverse()

        return self.fullPath, self.path'''
        New_maze = []
        id = 0

        B = mazeStr.split(' ')
        O_Maze = []

        for i in B:
            R = i.split(',')
            New_maze.append(R)
            R_Matrix = []

            for j in R:
                if j == 'S':
                    self.S = id

                if j == 'E':
                    self.E = id

                if j != '#':
                    R_Matrix.append(id)
                    id += 1
                else:
                    R_Matrix.append(-1)

            O_Maze.append(R_Matrix)

        #################################################################################################################################
        ################## enumerate  To Keep Traking ##########################3
        for l, i in enumerate(O_Maze):
            for m, j in enumerate(i):
                if j == -1:
                    continue

                n = Node(self)
                n.id = j
                '''if currentNode.up is not None:
                    if currentNode.up.visited_color == 'White':
                        self.node_2d_list[currentNode.up.row_index][currentNode.up.col_index].visited_color = 'Grey'
                        BFS_queue.appendleft(currentNode.up)
                        self.node_2d_list[currentNode.up.row_index][currentNode.up.col_index].previousNode = currentNode'''
                if l > 0:
                    n.up = O_Maze[l - 1][m]
                else:
                    n.up = -1

                if l < len(O_Maze) - 1:
                    n.down = O_Maze[l + 1][m]
                else:
                    n.down = -1

                if m > 0:
                    n.left = O_Maze[l][m - 1]
                else:
                    n.left = -1

                if m < len(i) - 1:
                    n.right = O_Maze[l][m + 1]
                else:
                    n.right = -1

                self.N[j] = n
        self.Maze = O_Maze
        ################################################################################################

        val = 0
        V_N = []
        ####################################################################################3
        # for l, i in (self.heuristic):
        # for m, j in (i):

        # if O_Maze[l][m] != -1:
        #   self.N[O_Maze[l][m]].hOfN = j
        # pass

        ################################################################################333333333
        if heristicValue != None:
            for i in heristicValue:
                V_N.append(i)
                val += 1
                if val == len(O_Maze[0]):
                    self.heuristic.append(V_N)
                    val = 0
                    V_N = []
        ####################################################################################3
        for l, i in enumerate(self.heuristic):
            for m, j in enumerate(i):

                if O_Maze[l][m] != -1:
                    self.N[O_Maze[l][m]].hOfN = j
        pass

    ##############################################################################################################


    ##############################################################################################################


    def goaltest(node):
        c = node.N[node.S]  # start node gwa el maze el na bt3mel m3haa
        startnode = node(c)
        visited = list([])
        Stack = deque([startnode])
        visited.append(startnode)
        if startnode == 'E':
            return startnode

    def seq(self):

        # to keep track of the sequence used to get to the goal
        node, seq = self, []
        while node:
            seq.append(node)
            node = node.last
            yield from reversed(seq)

    def DLS(Problem,Limit):

        return Recursive_DLS(Make_Node(Problem.IntialState),Problem,Limit)


    def Recursive_DLS(Node,problem,Limit):
        cutoff = True
        depth_limit = limit
        inital_state = Node
        if goaltest(Node.inital_state):
            return Node.inital_state # return sequence

        elif depth_limit == 0:
            cutoff = True
            return cutoff
        else:
            cutoff = False
            for action in actions(node.inital_state):

                child=Child_Node(Problem,Node,Action) # child=new child(Node.)

                Result=Recursive_DLS(child,problem,depth_limit-1)
                if cutoff:
                    cutoff=True
                    return cutoff
                else:
                    return Result
            #if cutoff==True:
            #    return cutoff
            else:
                return -1


#depth=50 stopping condition



    #############################################################################################################
    def BDS(self):
        # Fill the correct path in self.path
        # self.fullPath should contain the order of visited nodes
        return self.path, self.fullPath

    #############################################################################################
    def BFS(self):

        # Fill the correct path in self.path
        openList = []
        closelist = []
        v = {}

        c = self.N[self.S]

        v[c.id] = -1
        # c.id=-1
        ################################# Do While Loop ######################################
        while True:
            ############ Moving In Maze ##########################
            if c.left >= 0 and v.__contains__(c.left) == False:
                openList.append([self.N[c.left].hOfN, self.N[c.left], c.id])

            if c.right >= 0 and v.__contains__(c.right) == False:
                openList.append([self.N[c.right].hOfN, self.N[c.right], c.id])

            if c.up >= 0 and v.__contains__(c.up) == False:
                openList.append([self.N[c.up].hOfN, self.N[c.up], c.id])

            if c.down >= 0 and v.__contains__(c.down) == False:
                openList.append([self.N[c.down].hOfN, self.N[c.down], c.id])
            ###################################################################################################

            c = self.N[openList[0][2]]
            List_Next = openList[0][1]
            v[List_Next.id] = c.id
            c = List_Next
            del openList[0]
            if c.id == self.E:
                break

        closelist.append(c.id)
        total = 0
        ########################################################################################
        while True:
            c = self.N[v[c.id]]
            closelist.append(c.id)
            total += c.hOfN
            if v[c.id] == -1:
                break
        #############################################################################################
        closelist.reverse()
        self.path = closelist
        self.fullPath = list(v.keys())
        self.totalCost = total

        # self.fullPath should contain the order of visited nodes
        return self.path, self.fullPath, self.totalCost


##################################################################################################################

def main():
    searchAlgo = SearchAlgorithms('S,.,.,#,.,.,. .,#,.,.,.,#,. .,#,.,.,.,.,. .,.,#,#,.,.,. #,.,#,E,.,#,.')
    path, fullPath = searchAlgo.DLS()
    print('**DFS**\nPath is: ' + str(path) + '\nFull Path is: ' + str(fullPath) + '\n\n')
    # #
    # #             #######################################################################################
    # #
    searchAlgo = SearchAlgorithms('S,.,.,#,.,.,. .,#,.,.,.,#,. .,#,.,.,.,.,. .,.,#,#,.,.,. #,.,#,E,.,#,.')
    path, fullPath = searchAlgo.BDS()
    print('**BFS**\nPath is: ' + str(path) + '\nFull Path is: ' + str(fullPath) + '\n\n')
    #             #######################################################################################
    # #
    searchAlgo = SearchAlgorithms('S,.,.,#,.,.,. .,#,.,.,.,#,. .,#,.,.,.,.,. .,.,#,#,.,.,. #,.,#,E,.,#,.',
                                  [0, 15, 2, 100, 60, 35, 30,
                                   3, 100, 2, 15, 60, 100, 30,
                                   2, 100, 2, 2, 2, 40, 30,
                                   2, 2, 100, 100, 3, 15, 30,
                                   100, 2, 100, 0, 2, 100, 30])
    path, fullPath, TotalCost = searchAlgo.BFS()
    print('** UCS **\nPath is: ' + str(path) + '\nFull Path is: ' + str(fullPath) + '\nTotal Cost: ' + str(
        TotalCost) + '\n\n')
    #######################################################################################


main()
# end region